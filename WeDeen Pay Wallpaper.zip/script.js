const API_TOKEN = "D9OF9MWr2A3hAtJqvjx9GBEjOEKE0a2W";
const TABLE_ID = "816016";
const headers = { "Authorization": "Token " + API_TOKEN };

const gallery = document.getElementById("gallery");
const searchInput = document.getElementById("searchInput");
const downloadBtn = document.getElementById("downloadBtn");
const btnText = downloadBtn.querySelector(".btn-text");
const spinner = downloadBtn.querySelector(".spinner");

let allPosts = [];
let currentImage = "";

// Load Photos
async function loadPhotos() {
  try {
    const res = await fetch(`https://api.baserow.io/api/database/rows/table/${TABLE_ID}/?user_field_names=true`, { headers });
    const data = await res.json();
    allPosts = data.results;
    displayPhotos(allPosts);
  } catch (err) {
    console.error("Error fetching photos:", err);
  }
}

// Display Photos
function displayPhotos(posts) {
  gallery.innerHTML = "";
  posts.slice().reverse().forEach(post => {
    if (post.Photo && post.Photo.length > 0) {
      const imgUrl = post.Photo[0].url;
      const div = document.createElement("div");
      div.className = "photo-card";
      div.innerHTML = `<img src="${imgUrl}" onclick="openModal('${imgUrl}')">`;
      gallery.appendChild(div);
    }
  });
}

// Search
searchInput.addEventListener("input", () => {
  const searchText = searchInput.value.toLowerCase();
  const filtered = allPosts.filter(post =>
    post.Title && post.Title.toLowerCase().includes(searchText)
  );
  displayPhotos(filtered);
});

// Modal
function openModal(src) {
  currentImage = src;
  document.getElementById("modalImg").src = src;
  document.getElementById("imageModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("imageModal").style.display = "none";
}

// Download
downloadBtn.addEventListener("click", () => {
  if (!currentImage) return;
  
  spinner.style.display = "inline-block";
  btnText.textContent = "Downloading...";
  
  const a = document.createElement("a");
  a.href = currentImage;
  a.download = "photo.jpg";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  
  setTimeout(() => {
    spinner.style.display = "none";
    btnText.textContent = "Download Now";
  }, 1000);
});

loadPhotos();